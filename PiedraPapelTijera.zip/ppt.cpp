#include <iostream>
#include <time.h>
#include <stdlib.h>

#define TOTAL_JUGADAS 		5
#define TOTAL_TIPOS_MANOS	3


using namespace std;

int generarMano(int);
void mostrarMano(int);
int quienGano(int, int);
void informarGanador(int, int);
void mostrarJugada(int, int, int, int);
	
int main() {

	srand(time(NULL));
	
	int manoJugador1, manoJugador2;
	int ganaMano;
	
	int puntosJugador1 = 0;
	int puntosJugador2 = 0;
	
	cout << "Partida" << "\t" << "Jugador 1       Jugador 2\n\n";
	for (int partida=1; partida <= TOTAL_JUGADAS; partida++) {
		
		manoJugador1 = 	generarMano(TOTAL_TIPOS_MANOS);
		manoJugador2 = 	generarMano(TOTAL_TIPOS_MANOS);
		
		ganaMano = quienGano(manoJugador1, manoJugador2);
		
		if (ganaMano == 1) {
			puntosJugador1++;
		}
		else
			if (ganaMano == 2) {
				puntosJugador2++;
			}
			
		mostrarJugada(partida, manoJugador1, manoJugador2, ganaMano);
		
	}
	
	informarGanador(puntosJugador1, puntosJugador2);
	
	return 0;
}

int generarMano(int totalFiguras) {
	
	// Valores de Retorno:
	//					0: PIEDRA
	//					1: PAPEL
	//					2: TIJERA
	
	return rand() % TOTAL_TIPOS_MANOS;
	
}

void mostrarMano(int formaMano) {
	// Precondicion: 
	//      rango de formaMano: 0..TOTAL_TIPOS_MANOS-1
	
	switch (formaMano) {
		case 0:
			cout << "-PIEDRA-";
			break;
		case 1:
			cout << "-PAPEL- ";
			break;
		case 2:
			cout << "-TIJERA-";
			break;
	}
} 

void mostrarJugada(int partida, int manoJugador1, int manoJugador2, int ganaMano) {

	cout << endl << partida << "\t";
	mostrarMano(manoJugador1);
	cout << "\t";
	mostrarMano(manoJugador2);
	cout << "\t";
	cout << (ganaMano == 1 ? "Gana 1" : ganaMano == 2 ? "Gana 2" : "Empate");
	cout << endl;
	cout << "----------------------------------\n\n";	
}

int quienGano(int manoJugador1, int manoJugador2) {
	//  Valores de retorno:
	//			1: Gana el jugador 1
	//			2: Gana el jugador 2
	//			3: Empataron
	
	int valorGanador;
	
	if (manoJugador1 == manoJugador2) {
		valorGanador = 3;
	}
	else
		if (manoJugador1 == 0) {
			if (manoJugador2 == 1) {
				valorGanador = 2;
			}
			else {
				valorGanador = 1;
			}
		}
		else 
			if (manoJugador1 == 1) {
				if (manoJugador2 == 0) {
					valorGanador = 1;
				}
				else {
					valorGanador = 2;
				}
			}
			else
				// el valor de manoJugador1 por descarte de los anteriores es TIJERA:2 por lo cual 
				//aqui directamente pregunto por la mano del Jugador 2
				
				if (manoJugador2 == 0) {
					valorGanador = 2;
				}
				else
					// jugador 2 le queda la posibilidad de PAPEL
					{
						valorGanador = 1;
					}
	
	return valorGanador;				
	
}

void informarGanador(int puntosJugador1, int puntosJugador2) {
	
	if (puntosJugador1 == puntosJugador2) {
		cout << "Empataron!\n";
	}
	else
		if (puntosJugador1 > puntosJugador2) {
			cout << "Ha ganado el JUGADOR --1--\n";
		}
		else
		{
			cout << "Ha ganado el JUGADOR --2--\n";
		}
}
	
